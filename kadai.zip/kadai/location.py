from geopy.geocoders import Nominatim

geolocator = Nominatim(user_agent="get_weather")

class Location:

    def __init__(self, location, latitude, longitude):
        self.location = location
        self.latitude = latitude
        self.longitude = longitude

    def getLocationName(self):
        location = geolocator.geocode(self)
        return location

    def getLocationByCoordinate(self):
        location = geolocator.geocode(self)
        latitude = location.latitude
        longitude = location.longitude
        return {"latitude": latitude, "longitude": longitude}

# location = Location
# print(location.getLocationName('kawasaki'))
# print(location.getLocationByCoordinate('kawasaki'))